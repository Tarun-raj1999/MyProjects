package com.springBoot.kalviiBatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalviiBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalviiBatchApplication.class, args);
	}

}
