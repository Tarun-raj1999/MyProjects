package com.springBoot.KalviBatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalviBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
